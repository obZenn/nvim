# starter
Starter config for NvChad
